krakenex examples
=================

Here are some simple examples of how ``krakenex`` can be used.

They are not maintained to the same standard as the package itself,
and should be viewed as best-effort contributions by their respective
authors.

Be sure to understand what a script does before you run it with a valid
``kraken.key`` file!


License
-------

Simplified BSD. See ``LICENSE.txt``.
