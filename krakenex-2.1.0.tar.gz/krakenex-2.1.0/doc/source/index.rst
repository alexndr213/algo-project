.. krakenex documentation master file, created by
   sphinx-quickstart on Sat Apr 16 20:02:25 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

krakenex documentation
======================

.. toctree::
   :maxdepth: 4
   

      

Interface classes
-----------------

.. automodule:: krakenex
   :members:
   :imported-members:
   :special-members:
   :exclude-members: __dict__, __weakref__
   :private-members:
   :undoc-members:
   :show-inheritance:

